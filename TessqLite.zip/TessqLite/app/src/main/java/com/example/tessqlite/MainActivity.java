package com.example.tessqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.tessqlite.DatabaseHandler.Harga;

public class MainActivity extends AppCompatActivity {
    private EditText id, Nama, qty, exp, harga;
    private Button add, up, del;

    private Model barang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        id = findViewById(R.id.id);
        Nama = findViewById(R.id.nama);
        qty = findViewById(R.id.qty);
        exp = findViewById(R.id.ex);
        harga = findViewById(R.id.Harga);

        add = findViewById(R.id.btnAdd);
        barang = new Model();

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setData();
                saveData();
                Toast.makeText(getApplicationContext(), "Data Berhasil Disimpan", Toast.LENGTH_SHORT).show();
                clearData();
            }
        });
    }

    private void setData() {
        setId = id.getText().toString();
        setNama = Nama.getText().toString();
        setQty = qty.getSelectedItem().toString();
        setExp = exp.getSelectedItem().toString();
        setHarga = harga.getSelectedItem().toString();
    }

    private void saveData() {

        SQLiteDatabase create = barang.getWritableModel();

        ContentValues values = new ContentValues();
        values.put(barang.MyColumns.id, setid);
        values.put(barang.MyColumns.Nama, setNama);
        values.put(barang.MyColumns.Qty, setQty);
        values.put(barang.MyColumns.Exp, setExp);
        values.put(barang.MyColumns.Harga, setHarga);
        create.insert(barang.MyColumns.NamaTabel, null, values);
    }

    private void clearData() {
        id.setText("");
        Nama.setText("");
        qty.setText("");
        exp.setText("");
        harga.setText("");
    }
}