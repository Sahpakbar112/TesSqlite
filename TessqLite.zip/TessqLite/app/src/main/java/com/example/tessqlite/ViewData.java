package com.example.tessqlite;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewData  extends AppCompatActivity {

    private ListView listView;
    private Model MyDatabase;
    private ArrayList<String> ListData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.act_view);
        getSupportActionBar().setTitle("Daftar Barang");
        listView = findViewById(R.id.list);
        ListData = new ArrayList<>();
        MyDatabase = new Model();
        getData();
        listView.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, ListData));
    }

    @SuppressLint("Recycle")
    private void getData(){

        SQLiteDatabase ReadData = MyDatabase.getReadableDatabase();
        Cursor cursor = ReadData.rawQuery("SELECT * FROM "+ Model.MyColumns.NamaTabel,null);

        cursor.moveToFirst();

        for(int count=0; count < cursor.getCount(); count++){

            cursor.moveToPosition(count);

            ListData.add(cursor.getString(1));
        }
    }
}
