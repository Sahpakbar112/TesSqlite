package com.example.tessqlite;

public class Model{
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getQty() {
        return Qty;
    }

    public void setQty(String qty) {
        Qty = qty;
    }

    public String getExDate() {
        return ExDate;
    }

    public void setExDate(String exDate) {
        ExDate = exDate;
    }

    public String getHarga() {
        return Harga;
    }

    public void setHarga(String harga) {
        Harga = harga;
    }

    int id;
        String nama;
        String Qty,ExDate,Harga;
}
